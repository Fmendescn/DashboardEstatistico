# php mysql chartjs

Tutorial link [https://goo.gl/WtP4Us](https://goo.gl/WtP4Us)

How to draw Bar graph using data from MySQL table and PHP.
